import tensorflow as tf
import numpy as np
from PIL import Image
import mnist_forward
import mnist_backward
from redis import Redis, RedisError
import os
import socket
from flask import Flask, request, redirect, url_for
from werkzeug import secure_filename
from flask import send_from_directory

prevalue = 0
filename = "123"


import logging
import datetime

log = logging.getLogger()

log.setLevel('INFO')

handler = logging.StreamHandler()

handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))

log.addHandler(handler)

#from cassandra.cluster import Cluster

#from cassandra import ConsistencyLevel

from cassandra.cluster import Cluster

from cassandra.query import SimpleStatement

KEYSPACE = "mnistkeyspace"


def createKeySpace():
      

       cluster = Cluster(contact_points=['0.0.0.0'],port=9042)

       session = cluster.connect()

       log.info("Creating keyspace...")

       try:

          session.execute("""

          CREATE KEYSPACE %s

          WITH replication = { 'class': 'SimpleStrategy', 'replication_factor': '2' }

          """ % KEYSPACE)

          log.info("setting keyspace...")

          session.set_keyspace(KEYSPACE)

          log.info("creating table...")

          session.execute("""

          CREATE TABLE mytable (

              time timestamp,

              filename text	,

              prevalue int,

              PRIMARY KEY (time, filename, prevalue)

          )

          """)

         

       except Exception as e:

          log.error("Unable to create keyspace")

          log.error(e)  

def insertInformation():   
       global prevalue
       global filename
       
       cluster = Cluster(contact_points=['0.0.0.0'],port=9042)

       session = cluster.connect()

       try:

          log.info("inserting information...")
          session.execute("""
          INSERT INTO %smytable (
          time, filename, prevalue
          )
          VALUES (dateof(now()), %s , %d)
          """ %(KEYSPACE+".","\'"+filename+"\'",prevalue))
       except Exception as e:

          log.error("Unable to create keyspace")

          log.error(e)  

# 定义加载使用模型进行预测的函数
def restore_model(testPicArr):

    with tf.Graph().as_default() as tg:
        
        x = tf.placeholder(tf.float32,[None,mnist_forward.INPUT_NODE])
        y = mnist_forward.forward(x,None)
        preValue = tf.argmax(y,1)
        # 加载滑动平均模型
        variable_averages = tf.train.ExponentialMovingAverage(mnist_backward.MOVING_AVERAGE_DECAY)
        variables_to_restore = variable_averages.variables_to_restore()
        saver = tf.train.Saver(variables_to_restore)

        with tf.Session() as sess:
            
            ckpt = tf.train.get_checkpoint_state(mnist_backward.MODEL_SAVE_PATH)
            if ckpt and ckpt.model_checkpoint_path:
                # 恢复当前会话,将ckpt中的值赋值给w和b
                saver.restore(sess,ckpt.model_checkpoint_path)
                # 执行图计算
                preValue = sess.run(preValue,feed_dict={x:testPicArr})
                return preValue
            else:
                print("No checkpoint file found")
                return -1
# 图片预处理函数
def pre_pic(picName):
    # 先打开传入的原始图片
    img = Image.open(picName)
    # 使用消除锯齿的方法resize图片
    reIm = img.resize((28,28),Image.ANTIALIAS)
    # 变成灰度图，转换成矩阵
    im_arr = np.array(reIm.convert("L"))
    threshold = 50#对图像进行二值化处理，设置合理的阈值，可以过滤掉噪声，让他只有纯白色的点和纯黑色点
    for i in range(28):
        for j in range(28):
            im_arr[i][j] = 255-im_arr[i][j]
            if (im_arr[i][j]<threshold):
                im_arr[i][j] = 0
            else:
                im_arr[i][j] = 255
    # 将图像矩阵拉成1行784列，并将值变成浮点型（像素要求的仕0-1的浮点型输入）
    nm_arr = im_arr.reshape([1,784])
    nm_arr = nm_arr.astype(np.float32)
    img_ready = np.multiply(nm_arr,1.0/255.0)

    return img_ready



# Connect to Redis
redis = Redis(host="redis", db=0, socket_connect_timeout=2, socket_timeout=2)

UPLOAD_FOLDER = '/app'
ALLOWED_EXTENSIONS = set(['txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'])

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1] in ALLOWED_EXTENSIONS

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    createKeySpace()
    if request.method == 'POST':
        file = request.files['file']
        if file and allowed_file(file.filename):
            global filename
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            return redirect(url_for('uploaded_file',
                                    filename=filename))
    return '''
    <!doctype html>
    <title>Upload new File</title>
    <h1>Upload new File</h1>
    <form action="" method=post enctype=multipart/form-data>
      <p><input type=file name=file>
         <input type=submit value=Upload>
    </form>
    '''

@app.route('/uploads/<filename>')
def uploaded_file(filename):
        testPic = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        # 将图片路径传入图像预处理函数中
        testPicArr = pre_pic(testPic)
        # 将处理后的结果输入到预测函数最后返回预测结果
        global prevalue 
        prevalue= int(restore_model(testPicArr))
        insertInformation()
        return("The prediction number is :%d"%(prevalue))

       



if __name__ == "__main__":
    
    app.run(host='0.0.0.0', port=8080, debug=True)
 
